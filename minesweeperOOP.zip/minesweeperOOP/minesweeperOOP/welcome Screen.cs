﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace minesweeperOOP
{
    public partial class welcome_Screen : Form
    {
        MineSweeper MS = new MineSweeper();
        public welcome_Screen()
        {
            InitializeComponent();
            
        }


        private void btnStart_Click(object sender, EventArgs e)
        {
            switch (cmbLevelSel.Text) 
            {
                case "Beginer":
                    MS.row = 10;
                    MS.col = 10;
                    MS.bomb = 10;
                    this.Hide();
                    MS.ShowDialog();
                    
                    break;
                case"Expert":
                    MS.row = 16;
                    MS.col = 16;
                    MS.bomb = 40;
                    this.Hide();
                    MS.ShowDialog();
                    break;

                case"":
                    MessageBox.Show("Please Select Level");
                    break;
                default:
                    MessageBox.Show("Please Select Level");
                    break;
            
            }
            
            
        }
    }
}
