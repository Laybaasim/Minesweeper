﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace minesweeperOOP
{
    class Tile: Button
    {
        int _height;
        int _width;
        int noOfRows;
        
        public Tile(int height , int row)
        {
            _height = height;
            _width = height;
            noOfRows = row;
            this.Size = new System.Drawing.Size(_height, _width);
            //this.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Left = _height * row;
            this.Top = _width * row;
            this.Margin = new System.Windows.Forms.Padding(0);
            //this.BackColor = Color.DimGray;
            this.MouseUp += new MouseEventHandler(Tile_Click);
            this.EnabledChanged += new System.EventHandler(Tile_EnabledChanged);
           
        }

        void Tile_Click(object sender, MouseEventArgs e)
        {
            Button btn = (Button)sender;

            int x = btn.Left / _width;
            int y = btn.Top / _height;

            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {

                if (MineSweeper.board[x, y] == -1)
                {
                    MineSweeper.buttons[x, y].Enabled = false;
                    btn.Text = "\U0001F4A3";
                    btn.BackColor = System.Drawing.ColorTranslator.FromHtml("#D19C1D");
                    
                   bombDetected();

                }
                else
                {
                    if (MineSweeper.board[x, y] == 0)
                    {
                        btn.Text = "";
                        revealTile(x, y);
                    }
                    else
                    {
                        btn.Text = "" + MineSweeper.board[x, y];
                        
                    }
                }
                btn.Enabled = false;

            }
             
            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {

                btn.Text = "\U00002691";
                if(MineSweeper.board[x,y] == -1)
                {
                    MineSweeper.board[x, y] = -2;
                }
                
            }
        }


        private void revealTile(int x, int y)
        {
            Stack<Point> stack = new Stack<Point>();
            stack.Push(new Point(x, y)); //Push value in the stack

            while (stack.Count > 0)
            {
                Point p = stack.Pop();
                if (p.X < 0 || p.Y < 0) continue;
                if (p.X >= MineSweeper.board.GetLength(0) || p.Y >= MineSweeper.board.GetLength(1)) continue;
                if (!MineSweeper.buttons[p.X, p.Y].Enabled) continue;

                MineSweeper.buttons[p.X, p.Y].Enabled = false;


                if (MineSweeper.board[p.X, p.Y] != 0)
                {
                    MineSweeper.buttons[p.X, p.Y].Text = "" + MineSweeper.board[p.X, p.Y];

                }

                if (MineSweeper.board[p.X, p.Y] != 0) continue;

                stack.Push(new Point((p.X + 1), p.Y));
                stack.Push(new Point((p.X - 1), p.Y));
                stack.Push(new Point(p.X, (p.Y - 1)));
                stack.Push(new Point(p.X, (p.Y + 1)));

            }
        }

        private void Tile_EnabledChanged(object sender, System.EventArgs e)
        {
           Button btn = (Button)sender;
            btn.BackColor = Color.DimGray;
           
        }
        private void bombDetected()
        {
            MessageBox.Show("Game Over");
            for (int x = 0; x<noOfRows ;x++)
            {
                for(int y = 0; y<noOfRows;y++)
                {
                    if (MineSweeper.buttons[x, y].Enabled == false)
                        continue;
                 
                    
                    if(MineSweeper.board[x, y].ToString() == "-1")
                    {
                        MineSweeper.buttons[x, y].Enabled = false;
                        MineSweeper.buttons[x, y].Text = "\U0001F4A3";
                        MineSweeper.buttons[x, y].BackColor = Color.DarkRed;
                    }
                    else if (MineSweeper.board[x, y].ToString() == "0")
                    {
                        MineSweeper.buttons[x, y].Enabled = false;
                        MineSweeper.buttons[x, y].Text = "";
                    }
                    else if(MineSweeper.board[x, y].ToString() == "-2")
                    {
                       if(_height == 40)
                       {
                           MineSweeper.buttons[x, y].Image = Image.FromFile("bomb.png");
                       }
                       else if(_height == 20)
                       {
                           MineSweeper.buttons[x, y].Image = Image.FromFile("bomb1.png");
                       }

                        
                        MineSweeper.buttons[x, y].ImageAlign = ContentAlignment.MiddleCenter;
                        MineSweeper.buttons[x, y].BackColor = Color.Red;
                    }
                    else
                    {
                        MineSweeper.buttons[x, y].Enabled = false;
                        MineSweeper.buttons[x, y].Text = MineSweeper.board[x, y].ToString();
                        
                    }
                }
            }

            
           
        }
 
        }
}

     