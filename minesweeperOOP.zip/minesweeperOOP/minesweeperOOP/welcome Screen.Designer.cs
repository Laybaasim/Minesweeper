﻿namespace minesweeperOOP
{
    partial class welcome_Screen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(welcome_Screen));
            this.cmbLevelSel = new System.Windows.Forms.ComboBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cmbLevelSel
            // 
            this.cmbLevelSel.FormattingEnabled = true;
            this.cmbLevelSel.Items.AddRange(new object[] {
            "Beginer",
            "Expert"});
            this.cmbLevelSel.Location = new System.Drawing.Point(47, 304);
            this.cmbLevelSel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmbLevelSel.Name = "cmbLevelSel";
            this.cmbLevelSel.Size = new System.Drawing.Size(193, 24);
            this.cmbLevelSel.TabIndex = 0;
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(96, 350);
            this.btnStart.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(100, 28);
            this.btnStart.TabIndex = 1;
            this.btnStart.Text = "Start Game";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // welcome_Screen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(324, 446);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.cmbLevelSel);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "welcome_Screen";
            this.Text = "welcome_Screen";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbLevelSel;
        private System.Windows.Forms.Button btnStart;
    }
}