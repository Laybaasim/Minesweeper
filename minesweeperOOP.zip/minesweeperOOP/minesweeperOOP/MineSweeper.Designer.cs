﻿namespace minesweeperOOP
{
    partial class MineSweeper
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MineSweeper));
            this.flpTiles = new System.Windows.Forms.FlowLayoutPanel();
            this.btnRestart = new System.Windows.Forms.Button();
            this.lblTime = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tbpPanel = new System.Windows.Forms.TableLayoutPanel();
            this.lblFlag = new System.Windows.Forms.Label();
            this.tbpPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // flpTiles
            // 
            this.flpTiles.BackColor = System.Drawing.SystemColors.Control;
            this.flpTiles.Location = new System.Drawing.Point(0, 87);
            this.flpTiles.Margin = new System.Windows.Forms.Padding(0);
            this.flpTiles.Name = "flpTiles";
            this.flpTiles.Size = new System.Drawing.Size(267, 123);
            this.flpTiles.TabIndex = 0;
            // 
            // btnRestart
            // 
            this.btnRestart.AutoSize = true;
            this.btnRestart.BackColor = System.Drawing.SystemColors.Control;
            this.btnRestart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnRestart.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRestart.Location = new System.Drawing.Point(89, 0);
            this.btnRestart.Margin = new System.Windows.Forms.Padding(0);
            this.btnRestart.Name = "btnRestart";
            this.btnRestart.Size = new System.Drawing.Size(89, 59);
            this.btnRestart.TabIndex = 1;
            this.btnRestart.Text = "Restart";
            this.btnRestart.UseVisualStyleBackColor = false;
            this.btnRestart.Click += new System.EventHandler(this.btnRestart_Click);
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblTime.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblTime.Font = new System.Drawing.Font("MS Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.ForeColor = System.Drawing.Color.Red;
            this.lblTime.Location = new System.Drawing.Point(195, 0);
            this.lblTime.Margin = new System.Windows.Forms.Padding(0);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(72, 59);
            this.lblTime.TabIndex = 3;
            this.lblTime.Text = "Time";
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tbpPanel
            // 
            this.tbpPanel.BackColor = System.Drawing.Color.Transparent;
            this.tbpPanel.ColumnCount = 3;
            this.tbpPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tbpPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tbpPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tbpPanel.Controls.Add(this.lblFlag, 0, 0);
            this.tbpPanel.Controls.Add(this.lblTime, 2, 0);
            this.tbpPanel.Controls.Add(this.btnRestart, 1, 0);
            this.tbpPanel.Location = new System.Drawing.Point(0, 25);
            this.tbpPanel.Margin = new System.Windows.Forms.Padding(4);
            this.tbpPanel.Name = "tbpPanel";
            this.tbpPanel.RowCount = 1;
            this.tbpPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tbpPanel.Size = new System.Drawing.Size(267, 59);
            this.tbpPanel.TabIndex = 5;
            // 
            // lblFlag
            // 
            this.lblFlag.AutoSize = true;
            this.lblFlag.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblFlag.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblFlag.Font = new System.Drawing.Font("MS Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFlag.ForeColor = System.Drawing.Color.Red;
            this.lblFlag.Location = new System.Drawing.Point(0, 0);
            this.lblFlag.Margin = new System.Windows.Forms.Padding(0);
            this.lblFlag.Name = "lblFlag";
            this.lblFlag.Size = new System.Drawing.Size(72, 59);
            this.lblFlag.TabIndex = 4;
            this.lblFlag.Text = "Flag";
            // 
            // MineSweeper
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(596, 346);
            this.Controls.Add(this.tbpPanel);
            this.Controls.Add(this.flpTiles);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MineSweeper";
            this.Text = "MineSweeper";
            this.Load += new System.EventHandler(this.MineSweeper_Load);
            this.tbpPanel.ResumeLayout(false);
            this.tbpPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flpTiles;
        private System.Windows.Forms.Button btnRestart;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TableLayoutPanel tbpPanel;
        public System.Windows.Forms.Label lblFlags;
        private System.Windows.Forms.Label lblFlag;
        
    }
}

