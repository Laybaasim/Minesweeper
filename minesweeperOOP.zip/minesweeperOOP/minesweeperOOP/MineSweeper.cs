﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace minesweeperOOP
{
    public partial class MineSweeper : Form
    {
        public int row { get; set; }
        public int col { get; set; }
        public int bomb { get; set; }
      

        static public int[,] board;
        static public Button[,] buttons;

       
        int height;
        int width;
        int time;

        public MineSweeper()
        {
            InitializeComponent();
        }

        private void MineSweeper_Load(object sender, EventArgs e)
        {
            timer1.Start();
            ModeSelector();
            CreateBoard();
            SetupTiles();
            SetupMines();
        }

        private void ModeSelector()
        {
            if (row == 10) //Beginner
            {
                height = 40;
                width = 40;
            }
            else //Expert
            {
                height = 20;
                width = 20;
            }
        }
        private void CreateBoard()
        {

            flpTiles.Size = new System.Drawing.Size(row * height, row * height);
            tbpPanel.Size = new System.Drawing.Size(row * height, 20);
            lblFlag.Text = Convert.ToString(bomb);
            board = new int[row, col];
            buttons = new Button[row, col];


        }

        private void SetupTiles()
        {

            for (int x = 0; x < board.GetLength(0); x++)
            {
                for (int y = 0; y < board.GetLength(1); y++)
                {
                    Tile tp = new Tile(height, row);
                    buttons[y, x] = tp;
                    flpTiles.Controls.Add(tp);

                }
            }

        }

        private void SetupMines()
        {
            if (bomb > 0.8 * row * col)
                bomb = (int)(0.8 * row * col);

            Random rand = new Random();

            while (bomb > 0)
            {
                int x = rand.Next(row);
                int y = rand.Next(col);


                if (board[x, y] == -1) continue;
                board[x, y] = -1;


                for (int dx = -1; dx <= 1; dx++)
                {
                    for (int dy = -1; dy <= 1; dy++)
                    {
                        if (x + dx < 0) continue;
                        if (y + dy < 0) continue;
                        if (x + dx >= row) continue;
                        if (y + dy >= col) continue;
                        if (board[x + dx, y + dy] != -1)
                        {

                            board[x + dx, y + dy]++;
                        }
                    }
                }
                bomb--;
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            time++;
            lblTime.Text = Convert.ToString(time);
        }

        private void btnRestart_Click(object sender, EventArgs e)
        {
            this.Close();
            welcome_Screen ws = new welcome_Screen();
            ws.Show();
        }

       static public void Restart() 
        {
           
        }


         
       
        

    }
        

    }

