﻿namespace minesweeper2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnStart = new System.Windows.Forms.Button();
            this.cmbLvlSel = new System.Windows.Forms.ComboBox();
            this.lbllvl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnStart
            // 
            this.btnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStart.Location = new System.Drawing.Point(65, 315);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(94, 36);
            this.btnStart.TabIndex = 0;
            this.btnStart.Text = "Start Game!";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // cmbLvlSel
            // 
            this.cmbLvlSel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLvlSel.FormattingEnabled = true;
            this.cmbLvlSel.Items.AddRange(new object[] {
            "Beginner",
            "Expert"});
            this.cmbLvlSel.Location = new System.Drawing.Point(52, 278);
            this.cmbLvlSel.Name = "cmbLvlSel";
            this.cmbLvlSel.Size = new System.Drawing.Size(121, 21);
            this.cmbLvlSel.TabIndex = 1;
            this.cmbLvlSel.SelectedIndexChanged += new System.EventHandler(this.cmbLvlSel_SelectedIndexChanged);
            // 
            // lbllvl
            // 
            this.lbllvl.AutoSize = true;
            this.lbllvl.BackColor = System.Drawing.Color.Transparent;
            this.lbllvl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbllvl.ForeColor = System.Drawing.Color.White;
            this.lbllvl.Location = new System.Drawing.Point(60, 248);
            this.lbllvl.Name = "lbllvl";
            this.lbllvl.Size = new System.Drawing.Size(103, 20);
            this.lbllvl.TabIndex = 2;
            this.lbllvl.Text = "Select Level: ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Indigo;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(224, 367);
            this.Controls.Add(this.lbllvl);
            this.Controls.Add(this.cmbLvlSel);
            this.Controls.Add(this.btnStart);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form1";
            this.Text = "Minesweeper";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.ComboBox cmbLvlSel;
        private System.Windows.Forms.Label lbllvl;
    }
}

